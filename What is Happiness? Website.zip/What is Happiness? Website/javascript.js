var numberOfQuestions = 10;
var answers = 6;
function getCheckedValue( radioName ){
	var radios = document.getElementsByName( radioName );
	for(var y = 0; y < radios.length; y++) {
		if(radios[y].checked) {
			return radios[y].value;
		}
	}
}
function getScore(){
	var score = 0;
	for (var i = 0; i < numberOfQuestions; i++) {
		if (getCheckedValue("Q"+i) == "Strongly disagree") {
			score += 5;
		} else if (getCheckedValue("Q"+i) == "Moderately disagree") {
			score += 4;	
		} else if (getCheckedValue("Q"+i) == "Slightly disagree") {
			score += 3;	
		} else if (getCheckedValue("Q"+i) == "Slightly agree") {
			score += 2;	
		} else if (getCheckedValue("Q"+i) == "Moderately agree") {
			score += 1;	
		} else if (getCheckedValue("Q"+i) == "Strongly agree") {
			score += 0;	
		}
	}
	var finalScore = score/10;
	return finalScore;
}

function returnScore(){
	alert("Your score is " + getScore());
}


