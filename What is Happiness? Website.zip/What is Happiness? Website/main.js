'use strict';

setInterval(function() {
	console.log(new Date());
	
	}, 1000);
}
